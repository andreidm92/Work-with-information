# -*- coding: utf-8 -*-
import scrapy
from scrapy.http import HtmlResponse
from jobparser.items import JobparserItem

class HhruSpider(scrapy.Spider):
    name = 'hhru'
    allowed_domains = ['hh.ru']

    def __init__(self, vacansy):
        self.start_urls = [f'https://hh.ru/search/vacancy?area=1&st=searchVacancy&text={vacansy}&fromSearch=true&from=suggest_post']
    def parse(self, response:HtmlResponse):
        next_page = response.css('a.HH-Pager-Controls-Next::attr(href)').extract_first()
        job_links = response.xpath("//a[@class='bloko-link HH-LinkModifier']/@href").extract()
        for link in job_links:
            yield response.follow(link, callback=self.vacansy_parse)
        yield response.follow(next_page, callback=self.parse)



    def vacansy_parse(self, response: HtmlResponse):
        name = response.xpath("//h1/text()").extract_first()
        salary = response.xpath("//p[@class='vacancy-salary']//text()").extract()
        if salary[0] == "з/п не указана" :
             salary_min = None
             salary_max = None
        elif salary[0] == "от " and salary[2] == " до " :
             salary_min = salary[1]
             salary_max = salary[3]
        elif salary[0] == "от " :
             salary_min = salary[1]
             salary_max = None


        yield JobparserItem(name=name, salary_min=salary_min, salary_max=salary_min, salary=salary)


